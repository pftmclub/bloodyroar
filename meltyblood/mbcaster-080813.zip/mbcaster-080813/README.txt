The authors of MBCaster are in no way related to the original author of Caster.

Make sure you have the latest version (1.03a as of now).
If you are going to use keyboard, set inputDevice to 255 in caster_config.ini.
(A charInit() error is almost always related to this)
If you are getting TIMEOUT ( Away ) errors, try using option 6 (Try access ( Tough )) to connect.

STEP BY STEP GUIDE TO USING MBCASTER:

1 - Update MBAC to 1.03a.
2 - Copy the contents of the exe folder in the MBCaster .rar
    to THE EXACT SAME FOLDER THAT mbacPC.exe IS CONTAINED IN.
3 - Configure your input in the initial MBAC config menu. 
    If you are using keyboard, edit config_caster.ini appropiately. 
    (set inputDevice to 255, and edit the keys to your liking)
4 - Run mbcaster.exe, select option 9: Debug.
    This should bring you to the character select
    screen. If it does not, there is a 99% chance that you
    are doing something wrong.
    (GameGuard will prevent it from working, for example.)
5 - You're good to go! Option 1 will host, 
    2 will let you connect to someone hosting.