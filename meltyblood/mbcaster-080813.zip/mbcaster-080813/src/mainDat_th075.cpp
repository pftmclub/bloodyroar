#include "mainDatClass.h"
using namespace std;

//http://nienie.com/~masapico/doc_ApiSpy.html
//���̃y�[�W�uMASAPICO'S Page�v���Q�l

int mainDatClass::th075Roop( DWORD* deInfo ){


	BYTE newCode = 0xCC;
	CONTEXT ct;
	LDT_ENTRY ldtEntry;
	LPVOID pBase;
	NT_TIB tib;
	DWORD cbRead = 0;

	*deInfo = 0;
	/* �f�o�b�O�̌p�� */
	if( deInitFlg ){
		if( !ContinueDebugEvent(de.dwProcessId, de.dwThreadId, ContinueStatus) ){
			WaitForSingleObject( hPrintMutex, INFINITE );
			cout << "ERROR : ContinueDebugEvent" << endl;
			ReleaseMutex( hPrintMutex );
			return 1;
		}
	}else{
		deInitFlg = 1;
	}
	if( !WaitForDebugEvent(&de, INFINITE) ){
		WaitForSingleObject( hPrintMutex, INFINITE );
		cout << "ERROR : WaitForDebugEvent" << endl;
		ReleaseMutex( hPrintMutex );
		return 1;
	}

	ContinueStatus = DBG_EXCEPTION_NOT_HANDLED;

	switch(de.dwDebugEventCode) {
	case CREATE_PROCESS_DEBUG_EVENT:
		th075Flg = 1;
		hProcessTh  = de.u.CreateProcessInfo.hThread;
		processThID = de.dwThreadId;

		// Get StackBase
		ct.ContextFlags = CONTEXT_SEGMENTS;
		GetThreadContext( hProcessTh, &ct );
		GetThreadSelectorEntry( hProcessTh, ct.SegFs, &ldtEntry );
		pBase = (LPVOID)( ldtEntry.BaseLow +
				( ldtEntry.HighWord.Bytes.BaseMid << 16 ) +
				( ldtEntry.HighWord.Bytes.BaseHi << 24 ) );
		ReadProcessMemory( hProcess, pBase, &tib, sizeof( NT_TIB ), &cbRead );
		pStackBase = tib.StackBase;

		//priority
		if( priorityFlg == 1 ){
			SetPriorityClass( hProcess, ABOVE_NORMAL_PRIORITY_CLASS );
		}
		if( priorityFlg == 2 ){
			SetPriorityClass( hProcess, HIGH_PRIORITY_CLASS );
		}

		SetBodyBreakPoint();
		SetCharBreakPoint();
		SetCode();

		FlushInstructionCache(pi.hProcess, NULL, 0);
		break;

	case EXIT_PROCESS_DEBUG_EVENT:
		th075Flg = 0;
		return 1;

	case EXCEPTION_DEBUG_EVENT: /* ��O���� */
		switch(de.u.Exception.ExceptionRecord.ExceptionCode) {
        case EXCEPTION_ACCESS_VIOLATION:

            if (de.u.Exception.ExceptionRecord.ExceptionAddress > 0x0) {
             //   cout << "FATAL ERROR: Access violation at 0x" << hex << de.u.Exception.ExceptionRecord.ExceptionAddress << endl;
            }

            break;
		case EXCEPTION_BREAKPOINT:
			/* �u���[�N�|�C���g�ɑ��������ꍇ */
			ct.ContextFlags = CONTEXT_CONTROL;

			if( de.dwThreadId != processThID ){
				WaitForSingleObject( hPrintMutex, INFINITE );
				cout << "ERROR : processThID" << endl;
				ReleaseMutex( hPrintMutex );
				return 1;
			}
			if( !GetThreadContext(hProcessTh, &ct) ){
				WaitForSingleObject( hPrintMutex, INFINITE );
				cout << "ERROR : GetThreadContext" << endl;
				ReleaseMutex( hPrintMutex );
				return 1;
			}
			if(ct.Eip - 1 == body_int3_address) {
				*deInfo = de_body;

				updateKeybinds();
			} else if(ct.Eip - 1 == memLoc_wtfCfg1) {
				DWORD tmp;
				if(fixCfgFlg==1) {
					unsetPermissions();
				}
				ct.ContextFlags = CONTEXT_INTEGER | CONTEXT_CONTROL;
				GetThreadContext(hProcessTh, &ct);
				ct.Esp-=0x4;
				tmp=ct.Esp;
				if(!WriteProcessMemory(pi.hProcess, (void *)tmp, &ct.Esi, 4, NULL)){
					WaitForSingleObject( hPrintMutex, INFINITE );
					cout << "ERROR : Body breakpoint ( cfg )" << endl;
					ReleaseMutex( hPrintMutex );
					return 1;
				}

				FlushInstructionCache(pi.hProcess, NULL, 0);

				if(!SetThreadContext(hProcessTh, &ct)){
					WaitForSingleObject( hPrintMutex, INFINITE );
					cout << "ERROR : SetThreadContext ( cfg )" << endl;
					ReleaseMutex( hPrintMutex );
					return 1;
				}
				ct.ContextFlags = CONTEXT_CONTROL;

			} else if(ct.Eip - 1 == memLoc_wtfCfg2 || ct.Eip - 1 == memLoc_wtfCfg2a) {
				if(fixCfgFlg==1) {
					setPermissions();
				}

				ct.ContextFlags = CONTEXT_INTEGER | CONTEXT_CONTROL;
				GetThreadContext(hProcessTh, &ct);
				if(!ReadProcessMemory(pi.hProcess, (void *)ct.Esp, &ct.Esi, 4, NULL)){
					WaitForSingleObject( hPrintMutex, INFINITE );
					cout << "ERROR : Body breakpoint ( cfg )" << endl;
					ReleaseMutex( hPrintMutex );
					return 1;
				}

				FlushInstructionCache(pi.hProcess, NULL, 0);

				ct.Esp += 0x4;

				if(!SetThreadContext(hProcessTh, &ct)){
					WaitForSingleObject( hPrintMutex, INFINITE );
					cout << "ERROR : SetThreadContext ( cfg )" << endl;
					ReleaseMutex( hPrintMutex );
					return 1;
				}
				ct.ContextFlags = CONTEXT_CONTROL;
			} else if(ct.Eip - 1 == memLoc_rockTime) {
				BYTE code[2];
				DWORD tmp;

				ct.ContextFlags = CONTEXT_INTEGER | CONTEXT_CONTROL;
				GetThreadContext(hProcessTh, &ct);
				tmp=ct.Esp;
				tmp-=0x4;
				if(!WriteProcessMemory(pi.hProcess, (void *)tmp, &ct.Ebx, 4, NULL)){
					WaitForSingleObject( hPrintMutex, INFINITE );
					cout << "ERROR : Body breakpoint ( body )" << endl;
					ReleaseMutex( hPrintMutex );
					return 1;
				}
				tmp-=0x4;
				if(!WriteProcessMemory(pi.hProcess, (void *)tmp, &ct.Esi, 4, NULL)){
					WaitForSingleObject( hPrintMutex, INFINITE );
					cout << "ERROR : Body breakpoint ( body )" << endl;
					ReleaseMutex( hPrintMutex );
					return 1;
				}
				ct.Esp=tmp;

				FlushInstructionCache(pi.hProcess, NULL, 0);

				if(!SetThreadContext(hProcessTh, &ct)){
					WaitForSingleObject( hPrintMutex, INFINITE );
					cout << "ERROR : SetThreadContext ( body )" << endl;
					ReleaseMutex( hPrintMutex );
					return 1;
				}
				ct.ContextFlags = CONTEXT_CONTROL;

			}else if(ct.Eip - 1 == char_int3_address){
				*deInfo = de_char;
			}

			//�N�����ɏ�ɕK�v
			ContinueStatus = DBG_CONTINUE;

			break;

		case EXCEPTION_SINGLE_STEP: /* �V���O���X�e�b�v���s��O */
			/* �Ăуu���[�N�|�C���g��ݒu���� */
			if( !WriteProcessMemory(pi.hProcess, (void*)body_int3_address, &newCode, 1, NULL) ){
				WaitForSingleObject( hPrintMutex, INFINITE );
				cout << "ERROR : Set new code ( body )" << endl;
				ReleaseMutex( hPrintMutex );
				return 1;
			}

			FlushInstructionCache(pi.hProcess, NULL, 0);
			/* �V���O���X�e�b�v���[�h�𒆎~ */
			ct.ContextFlags = CONTEXT_CONTROL;
			if(!GetThreadContext(hProcessTh, &ct)){
				WaitForSingleObject( hPrintMutex, INFINITE );
				cout << "ERROR : GetThreadContext ( single step )" << endl;
				ReleaseMutex( hPrintMutex );
				return 1;
			}
			ct.EFlags &= ~EFLAGS_TF;
			if(!SetThreadContext(hProcessTh, &ct)){
				WaitForSingleObject( hPrintMutex, INFINITE );
				cout << "ERROR : SetThreadContext ( single step )" << endl;
				ReleaseMutex( hPrintMutex );
				return 1;
			}

			ContinueStatus = DBG_CONTINUE;
			break;
		}
		break;
	}


	return 0;
}

