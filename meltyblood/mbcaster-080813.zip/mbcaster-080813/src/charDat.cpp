//THIS FILE WAS SHAMELESSLY STOLEN (with some modifications) FROM CASTER

#include "charDatClass.h"
#include "const.h"
#include <shlwapi.h>
using namespace std;


charDatClass::charDatClass(){
	Button = &joyStatus.Button1;
	diFlg = 0;

	memset( inputBufBody, 0, sizeof( inputBufBody ) );
	memset( inputBufChar, 0, sizeof( inputBufChar ) );
	memset( &joyStatus, 0, sizeof( joyStatus ) );
	memset( keyStatus, 0, sizeof( keyStatus ) );

}

charDatClass::~charDatClass(){
	//none
}

void charDatClass::end(){
	if(diFlg){
		device->Unacquire();
		device->Release();
		di->Release();
		diFlg = 0;
	}
}

int charDatClass::init2p(){
	if( !(*th075Flg) ) return 1;
	BYTE iniBuf[10];
	BYTE usingtmp[1];
	char nowDir[200];
	char iniPath[200];

	memset( nowDir, 0, sizeof(nowDir) );
	strcpy( nowDir, "fail\0" );
	{
		char dir[200];

		if( GetModuleFileName( NULL, dir, 200 ) ){
			if( PathRemoveFileSpec( dir ) ){
				dir[199] = 0;
				strcpy( nowDir, dir );

				//��ƃt�H���_�ݒ�
				SetCurrentDirectory( nowDir );
			}
		}

		dir[199] = 0;
	}

	//iniPath
	strcpy( iniPath, "fail\0" );
	{
		char dir[200];
		if( strcmp( nowDir, "fail" ) && strlen( nowDir ) < 180 ){
			//ok
			strcpy( iniPath ,nowDir );
			strcat( iniPath, "\\config_caster.ini\0" );
		}
	}
	inputDeviceType = GetPrivateProfileInt( "INPUT", "inputDevice2p", 0, iniPath );

	//Let's just use default controls for now... we can add config possibilities later

	keyIniLeft  = GetPrivateProfileInt( "INPUT", "kLeft2p", 0xCB, iniPath ); // left arrow
	keyIniRight = GetPrivateProfileInt( "INPUT", "kRight2p", 0xCD, iniPath ); // right arrow
	keyIniUp    = GetPrivateProfileInt( "INPUT", "kUp2p", 0xC8, iniPath ); // up arrow
	keyIniDown  = GetPrivateProfileInt( "INPUT", "kDown2p", 0xD0, iniPath ); // down arrow
	keyIniA = GetPrivateProfileInt( "INPUT", "kA2p", 0x31, iniPath ); // n
	keyIniB = GetPrivateProfileInt( "INPUT", "kB2p", 0x32, iniPath ); // ,
	keyIniC = GetPrivateProfileInt( "INPUT", "kC2p", 0x33, iniPath ); // .
	keyIniD = GetPrivateProfileInt( "INPUT", "kD2p", 0x34, iniPath ); // /
	keyIniQ = GetPrivateProfileInt( "INPUT", "kQ2p", 0x24, iniPath ); // j
	keyIniAD = GetPrivateProfileInt( "INPUT", "kAD2p", 0x25, iniPath ); // k
	keyIniP = GetPrivateProfileInt( "INPUT", "kP2p", 0x3F, iniPath ); // f5

	/*Just for the record, for the other players, just read the next
	  10 bytes, and the next 1 byte for "using permissions".*/

	ReadProcessMemory( *hProcess , (void*)memLoc_p1Inputs , iniBuf , 10 , NULL );

	padIniA = iniBuf[0x0];
	padIniB = iniBuf[0x1];
	padIniC = iniBuf[0x2];
	padIniD = iniBuf[0x3];
	padIniQ = iniBuf[0x4];
	padIniAD = iniBuf[0x5];
	padIniAB = iniBuf[0x6];
	padIniABC = iniBuf[0x7]; // I think 0x8 is just a filler to make sure buttons 0-9 are all used
	padIniP = iniBuf[0x9];

	ReadProcessMemory( *hProcess , (void*)memLoc_p2Inputs , iniBuf , 10 , NULL );

	padIniA_2 = iniBuf[0x0];
	padIniB_2 = iniBuf[0x1];
	padIniC_2 = iniBuf[0x2];
	padIniD_2 = iniBuf[0x3];
	padIniQ_2 = iniBuf[0x4];
	padIniAD_2 = iniBuf[0x5];
	padIniAB_2 = iniBuf[0x6];
	padIniABC_2 = iniBuf[0x7]; // I think 0x8 is just a filler to make sure buttons 0-9 are all used
	padIniP_2 = iniBuf[0x9];

	ReadProcessMemory( *hProcess , (void*)memLoc_p2Permissions , usingtmp , 1 , NULL );

	// Note that 1 = do NOT use
	usingAD=(usingtmp[0]&1);
	usingAB=(usingtmp[0]&2)/2;
	usingABC=(usingtmp[0]&4)/4;
	ADPressed=1;
	ABPressed=1;
	ABCPressed=1;

	if( diInit() ){
		diFlg = 0;
		return 1;
	}

	diFlg = 1;
	return 0;
}

int charDatClass::init(){
	if( !(*th075Flg) ) return 1;
	BYTE iniBuf[10];
	BYTE usingtmp[1];
	char nowDir[200];
	char iniPath[200];

	memset( nowDir, 0, sizeof(nowDir) );
	strcpy( nowDir, "fail\0" );
	{
		char dir[200];

		if( GetModuleFileName( NULL, dir, 200 ) ){
			if( PathRemoveFileSpec( dir ) ){
				dir[199] = 0;
				strcpy( nowDir, dir );

				//��ƃt�H���_�ݒ�
				SetCurrentDirectory( nowDir );
			}
		}

		dir[199] = 0;
	}

	//iniPath
	strcpy( iniPath, "fail\0" );
	{
		char dir[200];
		if( strcmp( nowDir, "fail" ) && strlen( nowDir ) < 180 ){
			//ok
			strcpy( iniPath ,nowDir );
			strcat( iniPath, "\\config_caster.ini\0" );
		}
	}
	inputDeviceType = GetPrivateProfileInt( "INPUT", "inputDevice", 0, iniPath );

	//Let's just use default controls for now... we can add config possibilities later

	keyIniLeft  = GetPrivateProfileInt( "INPUT", "kLeft", 0xCB, iniPath ); // left arrow
	keyIniRight = GetPrivateProfileInt( "INPUT", "kRight", 0xCD, iniPath ); // right arrow
	keyIniUp    = GetPrivateProfileInt( "INPUT", "kUp", 0xC8, iniPath ); // up arrow
	keyIniDown  = GetPrivateProfileInt( "INPUT", "kDown", 0xD0, iniPath ); // down arrow
	keyIniA = GetPrivateProfileInt( "INPUT", "kA", 0x31, iniPath ); // n
	keyIniB = GetPrivateProfileInt( "INPUT", "kB", 0x32, iniPath ); // ,
	keyIniC = GetPrivateProfileInt( "INPUT", "kC", 0x33, iniPath ); // .
	keyIniD = GetPrivateProfileInt( "INPUT", "kD", 0x34, iniPath ); // /
	keyIniQ = GetPrivateProfileInt( "INPUT", "kQ", 0x24, iniPath ); // j
	keyIniAD = GetPrivateProfileInt( "INPUT", "kAD", 0x25, iniPath ); // k
	keyIniP = GetPrivateProfileInt( "INPUT", "kP", 0x3F, iniPath ); // f5

	//Always using 1p controls for joypad seems reasonable

	/*Just for the record, for the other players, just read the next
	  10 bytes, and the next 1 byte for "using permissions".*/

	ReadProcessMemory( *hProcess , (void*)memLoc_p1Inputs , iniBuf , 10 , NULL );

	padIniA = iniBuf[0x0];
	padIniB = iniBuf[0x1];
	padIniC = iniBuf[0x2];
	padIniD = iniBuf[0x3];
	padIniQ = iniBuf[0x4];
	padIniAD = iniBuf[0x5];
	padIniAB = iniBuf[0x6];
	padIniABC = iniBuf[0x7]; // I think 0x8 is just a filler to make sure buttons 0-9 are all used
	padIniP = iniBuf[0x9];
	ReadProcessMemory( *hProcess , (void*)memLoc_p2Inputs , iniBuf , 10 , NULL );

	padIniA_2 = iniBuf[0x0];
	padIniB_2 = iniBuf[0x1];
	padIniC_2 = iniBuf[0x2];
	padIniD_2 = iniBuf[0x3];
	padIniQ_2 = iniBuf[0x4];
	padIniAD_2 = iniBuf[0x5];
	padIniAB_2 = iniBuf[0x6];
	padIniABC_2 = iniBuf[0x7]; // I think 0x8 is just a filler to make sure buttons 0-9 are all used
	padIniP_2 = iniBuf[0x9];

	ReadProcessMemory( *hProcess , (void*)memLoc_p1Permissions , usingtmp , 1 , NULL );
	//cout << (int)usingtmp[0] << endl;
	permissionA = usingtmp[0];

	ReadProcessMemory( *hProcess , (void*)memLoc_p2Permissions , &permissionB , 1 , NULL );

	// Note that 1 = do NOT use
	usingAD=(usingtmp[0]&1);
	usingAB=(usingtmp[0]&2)/2;
	usingABC=(usingtmp[0]&4)/4;

	ADPressed=1;
	ABPressed=1;
	ABCPressed=1;

	if( diInit() ){
		diFlg = 0;
		return 1;
	}

	diFlg = 1;
	return 0;
}

int charDatClass::GetInput(){

	int Input = 0;

	if( !diFlg ) return 0;

	if(playerSide==0xA) {
		// Keyboard first
		if(inputDeviceType==0xFF) {
			if( device->GetDeviceState(256, keyStatus ) ){
				cout << "GetDeviceState Error" << endl;
			}

			if( keyStatus[keyIniLeft]  & 0x80 )	Input = Input | key_left;
			if( (keyStatus[keyIniRight] & 0x80) && !(keyStatus[keyIniLeft]  & 0x80) )	Input = Input | key_right;
			if( keyStatus[keyIniUp]  & 0x80 )	Input = Input | key_up;
			if( (keyStatus[keyIniDown] & 0x80) && !(keyStatus[keyIniUp]  & 0x80) )	Input = Input | key_down;
			if( keyStatus[keyIniA] & 0x80 )	Input = Input | key_A;
			if( keyStatus[keyIniB] & 0x80 )	Input = Input | key_B;
			if( keyStatus[keyIniC] & 0x80 )	Input = Input | key_C;
			if( keyStatus[keyIniD] & 0x80 )	Input = Input | key_D;
			if( keyStatus[keyIniQ] & 0x80 )	{ // Crappy hack to save 1 bit
				if(Input & key_left) {
					if(Input & key_up) {
						//7Q = NO EFFECT
					} else if(Input & key_down) {
						//1Q = NO EFFECT
					} else { Input = Input | key_right; } // 4Q = 4+6
				} else if(Input & key_right) {
					if(Input & key_up) {
						//9Q = NO EFFECT
					} else if(Input & key_down) {
						//3Q = NO EFFECT
					} else { Input = Input | key_up;
							Input = Input | key_left; } // 6Q = 4+6+8
				} else {
					if(Input & key_up) {
						//8Q = NO EFFECT
					} else if(Input & key_down) {
						Input = Input | key_up; // 2Q = 2+8
					} else {
						Input = Input | (key_left | key_right | key_up | key_down); // 5Q = 4+6+2+8
					}
				}
			}

			if(!usingAD) {
				if( keyStatus[keyIniAD] & 0x80 ) {
	/*				if(!ADPressed) {
						Input = Input | key_A;
						Input = Input | key_D;
					}
					ADPressed=1;
				} else { ADPressed=0; }*/
					Input = Input | key_AD;
				}
			}

			if( keyStatus[keyIniP] & 0x80 )	Input = Input | key_P;
		} else {
			//Now joypad

			if ( isPolledDevice )	device->Poll();
			if( device->GetDeviceState(80, &joyStatus) ){
				cout << "GetDeviceState Error" << endl;
			}

			if (joyStatus.X == 0 && joyStatus.Y == 0 && joyStatus.P1 != -1) {
				if (joyStatus.P1 <= povSensitivity || joyStatus.P1 >= 36000-povSensitivity) {
					joyStatus.Y = -1;
				} else if (joyStatus.P1 >= (18000-povSensitivity) && joyStatus.P1 <= (18000+povSensitivity)) {
					joyStatus.Y = 1;
				}
				if (joyStatus.P1 >= (9000-povSensitivity) && joyStatus.P1 <= (9000+povSensitivity)) {
					joyStatus.X = 1;
				} else if (joyStatus.P1 >= (27000-povSensitivity) && joyStatus.P1 <= (27000+povSensitivity)) {
					joyStatus.X = -1;
				}
			}

			// Let's make sure Q wasn't already registered, to prevent keyboard + pad from doing weird stuff
			if(!((Input & key_up) && (Input & key_down)) && !((Input & key_left) && (Input & key_right))) {
				if( joyStatus.X < 0 && !(Input & key_right)) {
					Input = Input | key_left;
				} else if( 0 < joyStatus.X  && !(Input & key_left)) {
					Input = Input | key_right;
				}
				if( joyStatus.Y < 0  && !(Input & key_down)){
					Input = Input | key_up;
				} else if ( 0 < joyStatus.Y  && !(Input & key_up)) {
					Input = Input | key_down;
				}

				if( Button[padIniQ] & 0x80 ) { // Crappy hack again
					if(Input & key_left) {
						if(Input & key_up) {
							//7Q = NO EFFECT
						} else if(Input & key_down) {
							//1Q = NO EFFECT
						} else { Input = Input | key_right; } //4Q = 4+6
					} else if(Input & key_right) {
						if(Input & key_up) {
							//9Q = NO EFFECT
						} else if(Input & key_down) {
							//3Q = NO EFFECT
						} else { Input = Input | key_up;
								Input = Input | key_left; } //6Q = 4+6+8
					} else {
						if(Input & key_up) {
							//8Q = NO EFFECT
						} else if(Input & key_down) {
							Input = Input | key_up; //2Q = 2+8
						} else {
							Input = Input | (key_left | key_right | key_up | key_down); //5Q = 4+6+2+8
						}
					}
				}
			}
			if( Button[padIniA] & 0x80 ) Input = Input | key_A;
			if( Button[padIniB] & 0x80 ) Input = Input | key_B;
			if( Button[padIniC] & 0x80 ) Input = Input | key_C;
			if( Button[padIniD] & 0x80 ) Input = Input | key_D;
			if(!usingAD) {
				if( Button[padIniAD] & 0x80 ) {
					Input = Input | key_AD;
					/*if(!ADPressed) {
						Input = Input | (key_A | key_D);
					}
					ADPressed=1;
				//} else if( !(keyStatus[keyIniAD] & 0x80) ) { ADPressed = 0; }
				} else { ADPressed = 0; }*/
				}

			}

			if(!usingAB) {
				if( Button[padIniAB] & 0x80 ) {
					Input = Input | key_AB;
					/*if(!ABPressed) {
						Input = Input | (key_A | key_B);
					}
					ABPressed=1;*/
				} //else { ABPressed = 0; }*/

			}

			if(!usingABC) {
				if( Button[padIniABC] & 0x80 ) {
					Input = Input | key_ABC;
				/*	if(!ABCPressed) {
						Input = Input | (key_A | key_B | key_C);
					}
					ABCPressed=1;
				} else { ABCPressed = 0; }*/
				}
			}
		}
	} else {
				// Keyboard first
		if(inputDeviceType==0xFF) {
			if( device->GetDeviceState(256, keyStatus ) ){
				cout << "GetDeviceState Error" << endl;
			}

			if( keyStatus[keyIniLeft]  & 0x80 )	Input = Input | key_left;
			if( (keyStatus[keyIniRight] & 0x80) && !(keyStatus[keyIniLeft]  & 0x80) )	Input = Input | key_right;
			if( keyStatus[keyIniUp]  & 0x80 )	Input = Input | key_up;
			if( (keyStatus[keyIniDown] & 0x80) && !(keyStatus[keyIniUp]  & 0x80) )	Input = Input | key_down;
			if( keyStatus[keyIniA] & 0x80 )	Input = Input | key_A;
			if( keyStatus[keyIniB] & 0x80 )	Input = Input | key_B;
			if( keyStatus[keyIniC] & 0x80 )	Input = Input | key_C;
			if( keyStatus[keyIniD] & 0x80 )	Input = Input | key_D;
			if( keyStatus[keyIniQ] & 0x80 )	{ // Crappy hack to save 1 bit
				if(Input & key_left) {
					if(Input & key_up) {
						//7Q = NO EFFECT
					} else if(Input & key_down) {
						//1Q = NO EFFECT
					} else { Input = Input | key_right; } // 4Q = 4+6
				} else if(Input & key_right) {
					if(Input & key_up) {
						//9Q = NO EFFECT
					} else if(Input & key_down) {
						//3Q = NO EFFECT
					} else { Input = Input | key_up;
							Input = Input | key_left; } // 6Q = 4+6+8
				} else {
					if(Input & key_up) {
						//8Q = NO EFFECT
					} else if(Input & key_down) {
						Input = Input | key_up; // 2Q = 2+8
					} else {
						Input = Input | (key_left | key_right | key_up | key_down); // 5Q = 4+6+2+8
					}
				}
			}

			if(!usingAD) {
				if( keyStatus[keyIniAD] & 0x80 ) {
					Input = Input | key_AD;
					/*
					if(!ADPressed) {
						Input = Input | key_A;
						Input = Input | key_D;
					}
					ADPressed=1;
				} else if(!usingAD) { ADPressed=0; }*/
				}
			}

			if( keyStatus[keyIniP] & 0x80 )	Input = Input | key_P;
		} else {
			//Now joypad

			if ( isPolledDevice )	device->Poll();
			if( device->GetDeviceState(80, &joyStatus) ){
				cout << "GetDeviceState Error" << endl;
			}

			if (joyStatus.X == 0 && joyStatus.Y == 0 && joyStatus.P1 != -1) {
				if (joyStatus.P1 <= povSensitivity || joyStatus.P1 >= 36000-povSensitivity) {
					joyStatus.Y = -1;
				} else if (joyStatus.P1 >= (18000-povSensitivity) && joyStatus.P1 <= (18000+povSensitivity)) {
					joyStatus.Y = 1;
				}
				if (joyStatus.P1 >= (9000-povSensitivity) && joyStatus.P1 <= (9000+povSensitivity)) {
					joyStatus.X = 1;
				} else if (joyStatus.P1 >= (27000-povSensitivity) && joyStatus.P1 <= (27000+povSensitivity)) {
					joyStatus.X = -1;
				}
			}

			// Let's make sure Q wasn't already registered, to prevent keyboard + pad from doing weird stuff
			if(!((Input & key_up) && (Input & key_down)) && !((Input & key_left) && (Input & key_right))) {
				if( joyStatus.X < 0 && !(Input & key_right)) {
					Input = Input | key_left;
				} else if( 0 < joyStatus.X  && !(Input & key_left)) {
					Input = Input | key_right;
				}
				if( joyStatus.Y < 0  && !(Input & key_down)){
					Input = Input | key_up;
				} else if ( 0 < joyStatus.Y  && !(Input & key_up)) {
					Input = Input | key_down;
				}

				if( Button[padIniQ_2] & 0x80 ) { // Crappy hack again
					if(Input & key_left) {
						if(Input & key_up) {
							//7Q = NO EFFECT
						} else if(Input & key_down) {
							//1Q = NO EFFECT
						} else { Input = Input | key_right; } //4Q = 4+6
					} else if(Input & key_right) {
						if(Input & key_up) {
							//9Q = NO EFFECT
						} else if(Input & key_down) {
							//3Q = NO EFFECT
						} else { Input = Input | key_up;
								Input = Input | key_left; } //6Q = 4+6+8
					} else {
						if(Input & key_up) {
							//8Q = NO EFFECT
						} else if(Input & key_down) {
							Input = Input | key_up; //2Q = 2+8
						} else {
							Input = Input | (key_left | key_right | key_up | key_down); //5Q = 4+6+2+8
						}
					}
				}
			}
			if( Button[padIniA_2] & 0x80 ) Input = Input | key_A;
			if( Button[padIniB_2] & 0x80 ) Input = Input | key_B;
			if( Button[padIniC_2] & 0x80 ) Input = Input | key_C;
			if( Button[padIniD_2] & 0x80 ) Input = Input | key_D;
			if(!usingAD) {
				if( Button[padIniAD_2] & 0x80 ) {
					Input = Input | key_AD;
					/*if(!ADPressed) {
						Input = Input | (key_A | key_D);
					}
					ADPressed=1;
				//} else if( !(keyStatus[keyIniAD] & 0x80) ) { ADPressed = 0; }
				} else { ADPressed = 0; }*/
				}
			}

			if(!usingAB) {
				if( Button[padIniAB_2] & 0x80 ) {
					Input = Input | key_AB;
					/*if(!ABPressed) {
						Input = Input | (key_A | key_B);
					}
					ABPressed=1;
				} else { ABPressed = 0; }*/
				}
			}

			if(!usingABC) {
				if( Button[padIniABC_2] & 0x80 ) {
					Input = Input | key_ABC;
					/*if(!ABCPressed) {
						Input = Input | (key_A | key_B | key_C);
					}
					ABCPressed=1;
				} else { ABCPressed = 0; }*/
				}
			}
		}
	}

	return Input;
}

void charDatClass::DecodeInput(int Input, BYTE* inputBuf, BYTE player) {
	// Screw pausing for now...

	// Time to decode the whole Q mess
	if(player==0xA) {
		if(((Input & key_up) && (Input & key_down)) || ((Input & key_left) && (Input & key_right))) {
			if((Input & (key_left | key_right | key_up | key_down)) == (key_left | key_right | key_up | key_down)) {
				if(inputBuf[padIniQ+1]==0) { inputBuf[padIniQ+1]=2; } else { inputBuf[padIniQ+1] = 1; }
				Input = Input ^ (key_left | key_right | key_up | key_down);
			} else {
				if((Input & (key_left | key_right | key_up)) == (key_left | key_right)){
					if(inputBuf[padIniQ+1]==0) { inputBuf[padIniQ+1]=2; } else { inputBuf[padIniQ+1] = 1; }
					Input = Input ^ key_right;
				}
				if((Input & (key_left | key_right | key_up)) == (key_left | key_right | key_up)){
					if(inputBuf[padIniQ+1]==0) { inputBuf[padIniQ+1]=2; } else { inputBuf[padIniQ+1] = 1; }
					Input = Input ^ (key_left | key_up);
				}
				if((Input & (key_up | key_down)) == (key_up | key_down)) {
					if(inputBuf[padIniQ+1]==0) { inputBuf[padIniQ+1]=2; } else { inputBuf[padIniQ+1] = 1; }
					Input = Input ^ key_up;
				}
			}
		} else { inputBuf[padIniQ+1] = 0; }

		if(Input & key_right || Input & key_left){
			if(Input & key_left){
				if(Input & key_up || Input & key_down){
					if(Input & key_up){
						if(inputBuf[0] & 0x7){
							inputBuf[0] = 0x7;
						} else { inputBuf[0] = 0x87; }
					}else{
						if(inputBuf[0] & 0x1){
							inputBuf[0] = 0x1;
						} else { inputBuf[0] = 0x81; }
					}
				}else{
					if(inputBuf[0] & 0x4){
						inputBuf[0] = 0x4;
					} else { inputBuf[0] = 0x84; }
				}
			}else{
				if(Input & key_up || Input & key_down){
					if(Input & key_up){
						if(inputBuf[0] & 0x9){
							inputBuf[0] = 0x9;
						} else { inputBuf[0] = 0x89; }
					}else{
						if(inputBuf[0] & 0x3){
							inputBuf[0] = 0x3;
						} else { inputBuf[0] = 0x83; }
					}
				}else{
					if(inputBuf[0] & 0x6){
						inputBuf[0] = 0x6;
					} else { inputBuf[0] = 0x86; }
				}
			}
		}else{
			if(Input & key_up || Input & key_down){
				if(Input & key_up){
					if(inputBuf[0] & 0x8){
						inputBuf[0] = 0x8;
					} else { inputBuf[0] = 0x88; }
				}else{
					if(inputBuf[0] & 0x2){
						inputBuf[0] = 0x2;
					} else { inputBuf[0] = 0x82; }
				}
			}else{
				inputBuf[0] = 0;
			}
		}



		if(Input & key_A){
			if(inputBuf[padIniA+1]==0) { inputBuf[padIniA+1]=2; } else { inputBuf[padIniA+1]=1; }
		}else{
			inputBuf[padIniA+1] = 0;
		}

		if(Input & key_B){
			if(inputBuf[padIniB+1]==0) { inputBuf[padIniB+1]=2; } else { inputBuf[padIniB+1]=1; }
		}else{
			inputBuf[padIniB+1] = 0;
		}

		if(Input & key_C){
			if(inputBuf[padIniC+1]==0) { inputBuf[padIniC+1]=2; } else { inputBuf[padIniC+1]=1; }
		}else{
			inputBuf[padIniC+1] = 0;
		}

		if(Input & key_D){
			if(inputBuf[padIniD+1]==0) { inputBuf[padIniD+1]=2; } else { inputBuf[padIniD+1]=1; }
		}else{
			inputBuf[padIniD+1] = 0;
		}

		if(Input & key_AD){
			if(inputBuf[padIniAD+1]==0) { inputBuf[padIniAD+1]=2; } else { inputBuf[padIniAD+1]=1; }
		}else{
			inputBuf[padIniAD+1] = 0;
		}

		if(Input & key_AB){
			if(inputBuf[padIniAB+1]==0) { inputBuf[padIniAB+1]=2; } else { inputBuf[padIniAB+1]=1; }
		}else{
			inputBuf[padIniAB+1] = 0;
		}

		if(Input & key_ABC){
			if(inputBuf[padIniABC+1]==0) { inputBuf[padIniABC+1]=2; } else { inputBuf[padIniABC+1]=1; }
		}else{
			inputBuf[padIniABC+1] = 0;
		}

		/*
		if(Input & key_P){
			if(inputBuf[padIniP+1]==0) { inputBuf[padIniP+1]=2; } else { inputBuf[padIniP+1]=1; }
		}else{
			inputBuf[padIniP+1] = 0;
		}
		 */

	} else if(player==0xB) {
		if(((Input & key_up) && (Input & key_down)) || ((Input & key_left) && (Input & key_right))) {
			if((Input & (key_left | key_right | key_up | key_down)) == (key_left | key_right | key_up | key_down)) {
				if(inputBuf[padIniQ_2+1]==0) { inputBuf[padIniQ_2+1]=2; } else { inputBuf[padIniQ_2+1] = 1; }
				Input = Input ^ (key_left | key_right | key_up | key_down);
			} else {
				if((Input & (key_left | key_right | key_up)) == (key_left | key_right)){
					if(inputBuf[padIniQ_2+1]==0) { inputBuf[padIniQ_2+1]=2; } else { inputBuf[padIniQ_2+1] = 1; }
					Input = Input ^ key_right;
				}
				if((Input & (key_left | key_right | key_up)) == (key_left | key_right | key_up)){
					if(inputBuf[padIniQ_2+1]==0) { inputBuf[padIniQ_2+1]=2; } else { inputBuf[padIniQ_2+1] = 1; }
					Input = Input ^ (key_left | key_up);
				}
				if((Input & (key_up | key_down)) == (key_up | key_down)) {
					if(inputBuf[padIniQ_2+1]==0) { inputBuf[padIniQ_2+1]=2; } else { inputBuf[padIniQ_2+1] = 1; }
					Input = Input ^ key_up;
				}
			}
		} else { inputBuf[padIniQ_2+1] = 0; }

		if(Input & key_right || Input & key_left){
			if(Input & key_left){
				if(Input & key_up || Input & key_down){
					if(Input & key_up){
						if(inputBuf[0] & 0x7){
							inputBuf[0] = 0x7;
						} else { inputBuf[0] = 0x87; }
					}else{
						if(inputBuf[0] & 0x1){
							inputBuf[0] = 0x1;
						} else { inputBuf[0] = 0x81; }
					}
				}else{
					if(inputBuf[0] & 0x4){
						inputBuf[0] = 0x4;
					} else { inputBuf[0] = 0x84; }
				}
			}else{
				if(Input & key_up || Input & key_down){
					if(Input & key_up){
						if(inputBuf[0] & 0x9){
							inputBuf[0] = 0x9;
						} else { inputBuf[0] = 0x89; }
					}else{
						if(inputBuf[0] & 0x3){
							inputBuf[0] = 0x3;
						} else { inputBuf[0] = 0x83; }
					}
				}else{
					if(inputBuf[0] & 0x6){
						inputBuf[0] = 0x6;
					} else { inputBuf[0] = 0x86; }
				}
			}
		}else{
			if(Input & key_up || Input & key_down){
				if(Input & key_up){
					if(inputBuf[0] & 0x8){
						inputBuf[0] = 0x8;
					} else { inputBuf[0] = 0x88; }
				}else{
					if(inputBuf[0] & 0x2){
						inputBuf[0] = 0x2;
					} else { inputBuf[0] = 0x82; }
				}
			}else{
				inputBuf[0]=0;
			}
		}



		if(Input & key_A){
			if(inputBuf[padIniA_2+1]==0) { inputBuf[padIniA_2+1]=2; } else { inputBuf[padIniA_2+1]=1; }
		}else{
			inputBuf[padIniA_2+1] = 0;
		}

		if(Input & key_B){
			if(inputBuf[padIniB_2+1]==0) { inputBuf[padIniB_2+1]=2; } else { inputBuf[padIniB_2+1]=1; }
		}else{
			inputBuf[padIniB_2+1] = 0;
		}

		if(Input & key_C){
			if(inputBuf[padIniC_2+1]==0) { inputBuf[padIniC_2+1]=2; } else { inputBuf[padIniC_2+1]=1; }
		}else{
			inputBuf[padIniC_2+1] = 0;
		}

		if(Input & key_D){
			if(inputBuf[padIniD_2+1]==0) { inputBuf[padIniD_2+1]=2; } else { inputBuf[padIniD_2+1]=1; }
		}else{
			inputBuf[padIniD_2+1] = 0;
		}

		if(Input & key_AD){
			if(inputBuf[padIniAD_2+1]==0) { inputBuf[padIniAD_2+1]=2; } else { inputBuf[padIniAD_2+1]=1; }
		}else{
			inputBuf[padIniAD_2+1] = 0;
		}

		if(Input & key_AB){
			if(inputBuf[padIniAB_2+1]==0) { inputBuf[padIniAB_2+1]=2; } else { inputBuf[padIniAB_2+1]=1; }
		}else{
			inputBuf[padIniAB_2+1] = 0;
		}

		if(Input & key_ABC){
			if(inputBuf[padIniABC_2+1]==0) { inputBuf[padIniABC_2+1]=2; } else { inputBuf[padIniABC_2+1]=1; }
		}else{
			inputBuf[padIniABC_2+1] = 0;
		}

		/*
		if(Input & key_P){
			if(inputBuf[padIniP_2+1]==0) { inputBuf[padIniP_2+1]=2; } else { inputBuf[padIniP_2+1]=1; }
		}else{
			inputBuf[padIniP_2+1] = 0;
		}
		 */
	}
//}
}

int charDatClass::SetInput( int Input ){
	//BYTE   pauseFlg;
	//DWORD  myBase;

	if( !(*th075Flg) ) return 1;
	if( !(*hProcess) ) return 1;

	DecodeInput(Input, inputBufBody, playerSide);

	if(playerSide==0xA){
		WriteProcessMemory(*hProcess,(void*)(memLoc_p1Input), inputBufBody, 11, NULL );
	}else{
		WriteProcessMemory(*hProcess,(void*)(memLoc_p2Input), inputBufBody, 11, NULL );
	}

	return 0;
}

int charDatClass::SetBodyInput( int Input ){
	return SetInput(Input);
}

int charDatClass::SetCharInput( int Input ){
	return SetInput(Input);
}

