#ifndef CASTER_CHARDAT
#define CASTER_CHARDAT

#if _MSC_VER >= 1300
#	include <windows.h>
#	define DIRECTINPUT_VERSION 0x0700//DirectX7 �� DirectInput���g�p
#	include <dinput.h>
#	include <iostream>
#else
#	include <windows.h>
#	include <dinput.h>
#	include <iostream.h>
#endif

#define key_up 1
#define key_down 2
#define key_left 4
#define key_right 8
#define key_A 16
#define key_B 32
#define key_C 64
#define key_D 128
#define key_AD 256
#define key_AB 512
#define key_ABC 1024
#define key_P 2048
//#define key_P 255 //Let's handle pauses later

//1p keys

#define defKeyLeft_A 0xCB // left arrow
#define defKeyRight_A 0xCD // right arrow
#define defKeyUp_A    0xC8 // up arrow
#define defKeyDown_A  0xD0 // down arrow
#define defKeyA_A  0x31 // n
#define defKeyB_A  0x32 // ,
#define defKeyC_A  0x33 // .
#define defKeyD_A  0x34 // /
#define defKeyQ_A  0x24 // j
#define defKeyAD_A  0x25 // k
#define defKeyP_A  0x3F // f5

//2p keys
// We don't really need this
/*
#define defKeyLeft_B   0x21 // f
#define defKeyRight_B  0x23 // h
#define defKeyUp_B     0x14 // t
#define defKeyDown_B   0x22 // g
#define defKeyA_B  0x2C // z
#define defKeyB_B  0x2D // x
#define defKeyC_B  0x2E // c
#define defKeyD_B  0x2F // v
#define defKeyQ_B  0x1E // a
#define defKeyAD_B  0x1F // s
#define defKeyP_B  0x3F // f5... is there a separate one for 2p?*/

typedef struct{
    LONG X;
    LONG Y;
    LONG Z;
    LONG Rx;
    LONG Ry;
    LONG Rz;
    LONG S1;
    LONG S2;
    LONG P1;
    LONG P2;
    LONG P3;
    LONG P4;
    BYTE Button1;
    BYTE Button2;
    BYTE Button3;
    BYTE Button4;
    BYTE Button5;
    BYTE Button6;
    BYTE Button7;
    BYTE Button8;
    BYTE Button9;
    BYTE Button10;
    BYTE Button11;
    BYTE Button12;
    BYTE Button13;
    BYTE Button14;
    BYTE Button15;
    BYTE Button16;
    BYTE Button17;
    BYTE Button18;
    BYTE Button19;
    BYTE Button20;
    BYTE Button21;
    BYTE Button22;
    BYTE Button23;
    BYTE Button24;
    BYTE Button25;
    BYTE Button26;
    BYTE Button27;
    BYTE Button28;
    BYTE Button29;
    BYTE Button30;
    BYTE Button31;
    BYTE Button32;
} joyStatusFormat;

class charDatClass{
	private:

	BYTE keyIniUp;
	BYTE keyIniDown;
	BYTE keyIniLeft;
	BYTE keyIniRight;
	BYTE keyIniA;
	BYTE keyIniB;
	BYTE keyIniC;
	BYTE keyIniD;
	BYTE keyIniQ;
	BYTE keyIniAD;
	BYTE keyIniAB; //not in use lol
	BYTE keyIniABC; //not in use lol
	BYTE keyIniP;

	//Pad stuffs

	BYTE padIniA;
	BYTE padIniB;
	BYTE padIniC;
	BYTE padIniD;
	BYTE padIniQ;
	BYTE padIniAD;
	BYTE padIniAB;
	BYTE padIniABC;
	BYTE padIniP;

	//And 2p's

	BYTE padIniA_2;
	BYTE padIniB_2;
	BYTE padIniC_2;
	BYTE padIniD_2;
	BYTE padIniQ_2;
	BYTE padIniAD_2;
	BYTE padIniAB_2;
	BYTE padIniABC_2;
	BYTE padIniP_2;

	//ARE WE USING THE FOLLOWING BUTTON COMBINATIONS?

	BYTE usingAD;
	BYTE usingAB;
	BYTE usingABC;

	BYTE ADPressed;
	BYTE ABPressed;
	BYTE ABCPressed;

	joyStatusFormat joyStatus;
	BYTE	keyStatus[256];
	BYTE* Button;
	BYTE inputBufBody[7];
	BYTE inputBufChar[7];

	LPDIRECTINPUT di;
	LPDIRECTINPUTDEVICE2 device;
	int isPolledDevice;

	public:
	charDatClass();
	~charDatClass();
	int	init();
	int init2p();
	int	diInit();
	int	GetInput();
	int	SetInput(int);
	int	SetBodyInput(int);
	int	SetCharInput(int);
	void DecodeInput(int, BYTE*, BYTE);
	void	end();


	GUID guid;
	BYTE inputDeviceType;
	WORD enumCounter;
	WORD playerSide;

	WORD	diFlg;
	WORD* th075Flg;
	HANDLE* hProcess;

	BYTE permissionA;
	BYTE permissionB;

	int povSensitivity;
};

#endif
