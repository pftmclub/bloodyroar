#include "mainDatClass.h"
using namespace std;

void mainDatClass::fixOptions() {
	BYTE code;
	// Let's make all options default (for now?)
	code=0;
	//WriteProcessMemory(hProcess,(void*)0x937598,&code,1,NULL); //Stage simplification (not needed?)
	WriteProcessMemory(hProcess,(void*)0x9375B8,&code,1,NULL); //Heat effect (probably not needed, but who cares)
	WriteProcessMemory(hProcess,(void*)0x9375BC,&code,1,NULL); //Handicap
	code=2;
	WriteProcessMemory(hProcess,(void*)0x9375D4,&code,1,NULL); //Damage Level
	WriteProcessMemory(hProcess,(void*)0x936844,&code,1,NULL); //Number of rounds
	WriteProcessMemory(hProcess,(void*)0x937594,&code,1,NULL); //Game speed

	//Let's also zero gameTime
	DWORD tmp=0;
	WriteProcessMemory(hProcess,(void*)memLoc_gameTime,&tmp,4,NULL);

	//Let's also fix RNG seed
	tmp=myRand;
	BYTE rngCode[6];
	rngCode[0]=0xc7;
	rngCode[1]=0x05;
	rngCode[2]=0x6c;
	rngCode[3]=0xd6;
	rngCode[4]=0x7a;
	rngCode[5]=0x00;
	WriteProcessMemory(hProcess,(void*)(memLoc_RNGseeding+0x6),&tmp,4,NULL);
	WriteProcessMemory(hProcess,(void*)memLoc_RNGseeding,&rngCode,6,NULL);

	// Unlock NAC
	BYTE NAC = 1;
	WriteProcessMemory(hProcess, (void*)0x9375a8, &NAC, 1, NULL);
}

BYTE LookUp(BYTE id) {
	BYTE table[] = { 0, 4, 5, 2, 102, 101, 108, 3, 100, 6,
		107, 11, 7, 9, 109, 8, 255, 103, 104, 255, 110, 255, 1,
		106, 10, 107 };
	if(id==0xFF) { return 105; } else { return table[id]; }
}

BYTE ManipMenuSub( charInfoStruct* now, charInfoStruct* dest){
	if(dest->phase > now->phase){
		switch( now->phase ){
		case 1 :
			//�܂��L�����̈ʒu�����킹��
			if( dest->ID != now->ID ){
				if(now->ID == 0xA && dest->ID == 0x19) {
					return key_D;
				}
				if(now->ID == 0x19 && dest->ID == 0xA) {
					return key_D;
				}
				if(abs(LookUp(dest->ID) - LookUp(now->ID)) > 60) {
					return key_up;
				} else {
					if(LookUp(dest->ID) > LookUp(now->ID)){
						if( LookUp(dest->ID) > LookUp(now->ID) + (MAX_CHARACTERS/2-1) ){
							return key_left;
						}else{
							return key_right;
						}
					}else{
						if( LookUp(dest->ID) + (MAX_CHARACTERS/2-1) < LookUp(now->ID) ){
							return key_right;
						}else{
							return key_left;
						}
					}
				}
			}else{
				//����
				return key_A;
			}
		case 2 :
			//color
			if( dest->ID != now->ID ){
				return key_B;
			}
			if( dest->color != now->color ){
				if((now->color - (now->color % COLOR_PAGE))!=(dest->color - (dest->color % COLOR_PAGE))) {
					if((now->color % COLOR_PAGE) == 0) {
						return key_down;
					} else if((now->color % COLOR_PAGE) == 5) {
						return key_up;
					} else { return key_right; }
				} else {
					if(dest->color > now->color){
						if( dest->color > now->color + (COLOR_PAGE/2-1) ){
							return key_up;
						}else{
							return key_down;
						}
					}else{
						if( dest->color + (COLOR_PAGE/2-1) < now->color ){
							return key_down;
						}else{
							return key_up;
						}
					}
				}
			}else{
				return key_A;
			}
		case 3 :
			//place
			if( dest->ID != now->ID ){
				return key_B;
			}
			if (dest->color != now-> color) {
				return key_B;
			}
			if (dest->place != now->place) {
//				return key_right;

				if(dest->place > now->place){
					return key_down;
				}else{
					return key_up;
				}
			}else{
				return key_A;
			}
		}
	}

	if(dest->phase < now->phase){
		//�L�����Z��
		if(now->phase>1 && (dest->phase==1 || dest->phase==2 || dest->phase==3)) { return key_B; }
	}

	if(dest->phase == now->phase){
		//�J�[�\���ړ�����
		switch( now->phase ){
		case 1 :
			//�L����������
			if( dest->ID != now->ID ){
				if(now->ID == 0xA && dest->ID == 0x19) {
					return key_D;
				}
				if(now->ID == 0x19 && dest->ID == 0xA) {
					return key_D;
				}
				if(abs(LookUp(dest->ID) - LookUp(now->ID)) > 60) {
					return key_up;
				} else {
					if(LookUp(dest->ID) > LookUp(now->ID)){
						if( LookUp(dest->ID) > LookUp(now->ID) + (MAX_CHARACTERS/2-1) ){
							return key_left;
						}else{
							return key_right;
						}
					}else{
						if( LookUp(dest->ID) + (MAX_CHARACTERS/2-1) < LookUp(now->ID) ){
							return key_right;
						}else{
							return key_left;
						}
					}
				}
			}
			break;
		case 2 :
			//color
			if( dest->ID != now->ID ){
				return key_B;
			}
			if( dest->color != now->color ){
				if((now->color - (now->color % COLOR_PAGE))!=(dest->color - (dest->color % COLOR_PAGE))) {
					if((now->color % COLOR_PAGE) == 0) {
						return key_down;
					} else if((now->color % COLOR_PAGE) == 5) {
						return key_up;
					} else { return key_right; }
				} else {
					if(dest->color > now->color){
						if( dest->color > now->color + (COLOR_PAGE/2-1) ){
							return key_up;
						}else{
							return key_down;
						}
					}else{
						if( dest->color + (COLOR_PAGE/2-1) < now->color ){
							return key_down;
						}else{
							return key_up;
						}
					}
				}
			}
		case 3 :
			//place
			if( dest->ID != now->ID ){
				return key_B;
			}
			if (dest->color != now-> color) {
				return key_B;
			}
			if (dest->place != now->place) {
//				return key_right;

				if(dest->place > now->place){
					return key_down;
				}else{
					return key_up;
				}
			}
		}
	}

	return 0;
}



int mainDatClass::ManipMenu(){
	#if debug_mode_mainRoop
		WaitForSingleObject( hPrintMutex, INFINITE );
		cout << "debug : ManipMenu()" << endl;
		ReleaseMutex( hPrintMutex );
	#endif

	memset( &enInfo, 0, sizeof(enInfo));

	//DWORD menuAddress = 0;	//0x12FD14			//DWORD
	//DWORD menuFlg = 0;	//0x12FE5C			//BYTE
	DWORD gameMode = 10;	//0x671418 + 0x218	//BYTE
	//DWORD battleFlgA = 0;	//0x671418			//DWORD
	//DWORD battleFlgB = 0;	//0x67141C			//DWORD

	//DWORD tmpAddress;

	WORD pushFlg = 0;
	BYTE InputA;
	BYTE InputB;
	//BYTE LastInputA;
	//BYTE LastInputB;

	//LastInputA = 0;
	//LastInputB = 0;

	myInfo.A.phase = 1;
	myInfo.B.phase = 1;

	enInfo.A.phase = 1;
	enInfo.B.phase = 1;

	enInfo.A.ID = 0x12;
	enInfo.B.ID = 0x17;

	dataInfo.A.phase = 1;
	dataInfo.B.phase = 1;

	datA.SetBodyInput( 0 );
	datB.SetBodyInput( 0 );

	myInfo.gameTime = 0;
	enInfo.gameTime = 0;
	dataInfo.gameTime = 0;

	//test
	//DWORD menuAddressTemp = 0;

	//�ɘa
	DWORD roopCounter = 0;
	//DWORD stageRandCounter = 0;
	//DWORD roopCounterKey = 0;

	//WORD roundShowFlg = 0;


	HWND hWnd = FindProcess();

	//�X�e�[�W�I���ُ̈�ɉ��}�[�u
	//WORD placeRecoverFlg = 0;

	//�X�e�[�W�I�������R��
	//WORD placeFreeFlg = 0;

	DWORD keyCancelCounter = 0;

	DWORD deInfo;


	srand (time(NULL));
	do {
        ReadProcessMemory( hProcess, (void*)memLoc_gameMode , &gameMode , 1 , NULL );

		if( th075Roop( &deInfo ) ) return 0xF;
		if( !roopFlg ){
			UnRockTime();
			return 1;
		}

        ReadProcessMemory( hProcess, (void*)memLoc_gameMode , &gameMode , 1 , NULL );
	} while (gameMode != 0);
	for(;;){
		if( th075Roop( &deInfo ) ) return 0xF;
		if( !roopFlg ){
			UnRockTime();
			//cout << "Second BAM" << endl;
			return 1;
		}
		if( deInfo == de_body ){
			myInfo.phase = phase_menu;
			InputA = 0;
			InputB = 0;

			ReadProcessMemory( hProcess, (void*)memLoc_gameMode , &gameMode , 1 , NULL );
			if (gameMode == 2) {
			    datA.SetInput( 0 );
			    datB.SetInput( 0 );
			    return 1;
			}

			if (gameMode == 3 || gameMode == 8 || gameMode == 5) {
			    myInfo.phase = 5;
			    break;
			}
			ReadProcessMemory( hProcess, (void*)0x4e7c4c, &myInfo.A.phase , 1 , NULL );
			if(myInfo.A.phase==0x03) { myInfo.A.phase=2; }
			if(myInfo.A.phase==0xf0) { myInfo.A.phase=3; }
			ReadProcessMemory( hProcess, (void*)0x4e7c74, &myInfo.B.phase , 1 , NULL );
			if(myInfo.B.phase==0x03) { myInfo.B.phase=2; }
			if(myInfo.B.phase==0xf0) { myInfo.B.phase=3; }
			DWORD tmp;
			if(myInfo.A.phase==3 && myInfo.B.phase==3) {
				tmp=myRand;
			} else {
				tmp=rand();
			}
			WriteProcessMemory(hProcess,(void*)memLoc_RNGseed,&tmp,4,NULL);

			ReadProcessMemory( hProcess, (void*)0x7EE4E8, &myInfo.A.ID , 1 , NULL );
			ReadProcessMemory( hProcess, (void*)0x7EE504, &myInfo.B.ID , 1 , NULL );

			ReadProcessMemory( hProcess, (void*)0x7CA698, &myInfo.place , 1 , NULL );
			ReadProcessMemory( hProcess, (void*)0x7EE4E4, &myInfo.A.color, 1, NULL);
			ReadProcessMemory( hProcess, (void*)0x7EE500, &myInfo.B.color, 1, NULL);

			myInfo.A.place = myInfo.place;
			myInfo.B.place = myInfo.place;

			fixOptions();

			if( myInfo.terminalMode == mode_broadcast || myInfo.terminalMode == mode_root || myInfo.terminalMode == mode_debug ){
				dataInfo = myInfo;
			}


				if( myInfo.terminalMode == mode_root || myInfo.terminalMode == mode_debug ){
					//���[�g�̏ꍇ
					if( enInfo.phase == phase_battle || enInfo.phase == phase_read ){
						enInfo.A.phase = 5;
						enInfo.B.phase = 5;
					}

					//�f�[�^��v��
					if (myInfo.terminalMode == mode_debug) {
						enInfo = myInfo;
					} else {
						SendCmd( dest_away, cmd_gameInfo );
					}

					//delay
						WORD delayTimeNew = 0;
						if (keystate[KEY_DELAY1] == 1) delayTimeNew = 2;
						if (keystate[KEY_DELAY2] == 1) delayTimeNew = 4;
						if (keystate[KEY_DELAY3] == 1) delayTimeNew = 6;
						if (keystate[KEY_DELAY4] == 1) delayTimeNew = 8;
						if (keystate[KEY_DELAY5] == 1) delayTimeNew = 10;
						if (keystate[KEY_DELAY6] == 1) delayTimeNew = 12;
						if (keystate[KEY_DELAY7] == 1) delayTimeNew = 14;
						if (keystate[KEY_DELAY8] == 1) delayTimeNew = 16;
						if (keystate[KEY_DELAY9] == 1) delayTimeNew = 18;
						if (keystate[KEY_DELAY10] == 1) delayTimeNew = 20;
						if( delayTimeNew ){
							if( hWnd == GetForegroundWindow() ){
								if( delayTime != delayTimeNew ){
									delayTime = delayTimeNew;
									cout << "debug : Buffer Margin ( delayTime ) " << delayTime / 2 << endl;
								}
							}
						}



					//if(menuFlg == 3 && battleFlgA == 0 && battleFlgB == 0 ){
					if(gameMode==0) {
						if( myInfo.playerSide == 0xA ){
							InputA = datA.GetInput();

							//�O�ʂ��ǂ���
							if( datA.inputDeviceType == 0xFF ){
								if( hWnd != GetForegroundWindow() ){
									InputA = 0;
								}
							}
							if( myInfo.terminalMode == mode_debug ){
								if( myInfo.A.phase > 1 && myInfo.B.phase > 1 ){
									if( keyCancelCounter > 40 ){
										//none
									}else{
										InputA = 0;
										keyCancelCounter++;
									}
								}
							}



							InputB = ManipMenuSub( &myInfo.B, &enInfo.B );
							if( myInfo.B.phase == 3 && InputB != key_B ){
								InputB = 0;
							}
						}
						if( myInfo.playerSide == 0xB ){
							//�e�X�g
							if( enInfo.A.place > MAX_STAGES-1 ){
								enInfo.A.place = 0;
							}
							if(enInfo.A.phase>0) {
								InputA = ManipMenuSub( &myInfo.A, &enInfo.A );
							}

							InputB = datA.GetInput();

							//�O�ʂ��ǂ���
							if( datA.inputDeviceType == 0xFF ){
								if( hWnd != GetForegroundWindow() ){
									InputB = 0;
								}
							}

							if( myInfo.B.phase == 3 && InputB != key_B ){
								InputB = 0;
							}
						}

						if( myInfo.A.phase == 3 && myInfo.B.phase == 3 && myInfo.sessionNo == enInfo.sessionNo){
							//���؂���
							if( myInfo.A.ID == enInfo.A.ID && myInfo.B.ID == enInfo.B.ID && myInfo.place == enInfo.place)
							{
								if(enInfo.phase == phase_battle || enInfo.phase == phase_read) { InputA = key_A; }
							}
						}
					}else{
						datA.SetInput( 0 );
						datB.SetInput( 0 );

						if( myInfo.playerSide == 0xA ){
							break;
						}else{
							//���؂���
							if(myInfo.A.ID == enInfo.A.ID && myInfo.B.ID == enInfo.B.ID && myInfo.place == enInfo.place)
							{
								//���̃X�e�b�v��
								break;
							}else{
								return 1;
							}
						}
					}


					//�A�ŏC��
					if( pushFlg ){
						if( myInfo.playerSide == 0xA ) InputB = 0;
						if( myInfo.playerSide == 0xB ) InputA = 0;
					}

					//sessionNo
					if( myInfo.sessionNo != enInfo.sessionNo ){
						if( myInfo.playerSide == 0xA ){
							InputB = 0;
						}
						if( myInfo.playerSide == 0xB ){
							InputA = 0;
						}
					}

				}else if( myInfo.terminalMode == mode_branch || myInfo.terminalMode == mode_subbranch ){
					//�]���̏ꍇ
					if( dataInfo.phase == phase_battle || dataInfo.phase == phase_read || gameMode == 1 || gameMode == 8 ){
						dataInfo.A.phase = 5;
						dataInfo.B.phase = 5;
					}

					    if (gameMode == 8 || gameMode == 1) {
                            break;
					    }


					//�f�[�^��v��
					if( !roopCounter ){
						SendCmd( dest_root, cmd_dataInfo );
					}
					roopCounter++;
					if( roopCounter > 6 ) roopCounter = 0;

					if( gameMode==0 ){
						InputA = ManipMenuSub( &myInfo.A, &dataInfo.A );
						InputB = ManipMenuSub( &myInfo.B, &dataInfo.B );

						if( myInfo.B.phase == 3 && InputB != key_B ){
							InputB = 0;
						}
						//���؂���
						if( (dataInfo.phase == phase_battle || dataInfo.phase == phase_read ) && ( myInfo.A.phase == 3 && myInfo.B.phase == 3 ) ){
							if( myInfo.A.ID == dataInfo.A.ID && myInfo.B.ID == dataInfo.B.ID && myInfo.place == dataInfo.place)
							{
								InputA = key_A;
							}
						}
					}else{
						datA.SetInput( 0 );
						datB.SetInput( 0 );

						//���؂���
						if( myInfo.A.ID == dataInfo.A.ID && myInfo.B.ID == dataInfo.B.ID && myInfo.place == dataInfo.place)
						{
							//���̃X�e�b�v��
							break;
						}else{
							return 1;
						}
					}

					//�A�ŏC��
					if( pushFlg ){
						InputA = 0;
						InputB = 0;
					}
				}else if( myInfo.terminalMode == mode_broadcast ){
					//�u���[�h�L���X�g�̏ꍇ
					if( gameMode==0 ){
						InputA = datA.GetInput();
						if( datA.inputDeviceType == 0xFF ){
							if( hWnd != GetForegroundWindow() ){
								InputA = 0;
							}
						}
						InputB = datB.GetInput();
						if( datB.inputDeviceType == 0xFF ){
							if( hWnd != GetForegroundWindow() ){
								InputB = 0;
							}
						}
					}else{
						//���̃X�e�b�v��
						break;
					}
				}

				if( myInfo.terminalMode == mode_debug && !practiceModeFlg){
					if( myInfo.A.phase > 2 && myInfo.B.phase < 3 ){
						if( keyCancelCounter > 20 ){
							InputB = InputA;
							if( myInfo.B.phase == 1 && InputA & key_B ){
								//none
								InputB = 0; // I'm pretty sure we need this?
							}else{
								InputA = 0;
							}
						}else{
							keyCancelCounter++;
						}
					}else{
						if( myInfo.A.phase > 1 && myInfo.B.phase > 1 ){
							//none
						}else{
							//InputB = datB.GetInput();
							keyCancelCounter = 0;
						}
					}
				}

				if( pushFlg ){
					pushFlg--;
				}else{
					pushFlg = 5;
				}

			datA.SetBodyInput( InputA );
			datB.SetBodyInput( InputB );

			//LastInputA = InputA;
			//LastInputB = InputB;

		}
	}
	return 0;
}
