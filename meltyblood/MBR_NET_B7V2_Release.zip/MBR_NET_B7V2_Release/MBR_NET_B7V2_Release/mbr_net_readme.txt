This software is the release version of MBR.NET 0.07.2 beta.

You can find the newest release version of Dot NET series in my blog:

http://spaces.msn.com/drwch